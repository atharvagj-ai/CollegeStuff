# Mongo-Flexmonster-Connector
Bda Project Code - https://github.com/rishabkoul/BdaProject
Bda Project Demo - https://ecommerse-analysis.herokuapp.com/
